module.exports = {

  // LIMIT_VALUE
  LIMIT_VALUE_NOT_FOUND: 'Limit Value not found',
  SUCCESS_GET_DETAIL_LIMIT_VALUE: 'Success Get Detail Limit Value Success',
  FAIL_GET_DETAIL_LIMIT_VALUE: 'Failed to Get Detail Limit Value',
  LIMIT_VALUE_HIDE_SUCCESS: 'Limit Value Hide Status Updated Successfully',
  LIMIT_VALUE_HIDE_FAIL: 'Failed to Update Limit Value Hide Status',
};
