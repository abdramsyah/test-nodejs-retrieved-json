const router = require('express').Router();
const promo = require('./promo');

router.use(promo);

module.exports = router;
