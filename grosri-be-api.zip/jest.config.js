
module.exports = {
  testEnvironment: 'node',
};
