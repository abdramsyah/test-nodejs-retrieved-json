'use strict';

const events = [
  {
    id: 1,
    event_name: 'Ramadhan Kareem',
    slug: 'ramadhan-kareem',
    is_active: true,
  },
  {
    id: 2,
    event_name: 'Mungkin Kamu Suka',
    slug: `mks`,
    is_active: true,
  },
  {
    id: 3,
    event_name: 'September',
    slug: `september`,
    is_active: false,
  },
];

events.forEach((e) => {
  e.createdAt = new Date();
  e.updatedAt = new Date();
});

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Events', events, {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Events', null, {});
  },
};
