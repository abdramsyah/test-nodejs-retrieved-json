const emailOtpGrosri = require('./otpGrosri');
const emailUpdatePasswordAdmin = require('./updatePasswordAdmin');

module.exports = { emailOtpGrosri, emailUpdatePasswordAdmin };
