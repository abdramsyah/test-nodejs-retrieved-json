const { ProductController } = require('./product');

module.exports = {
  ProductController,
};
