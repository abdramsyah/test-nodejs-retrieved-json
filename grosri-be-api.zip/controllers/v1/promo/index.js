const { PromoController } = require('./promo');

module.exports = {
  PromoController,
};
