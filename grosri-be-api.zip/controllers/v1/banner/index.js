const { BannerController } = require('./banner');

module.exports = {
  BannerController,
};
