const { cekToken } = require('../../../helpers/generalHelpers');
const { Banners, Companies, Company } = require('../../../models');
const { outputParser } = require('../../../utils/outputParser');
const { ROLES, STATUS } = require('../../../config/constant');
const Op = require('sequelize').Op;
const Paginator = require('../../../helpers/paginator');
const { Log } = require('../../../utils/customLog');
const { validationResult } = require('express-validator');
const { generateCompanyCode } = require('../../../utils/generatedCompany');

class CompanyController {
  static async getListPartner(req, res) {
    let queryResult = null;
    let { page, size: limit, search } = req.query;
    const paging = new Paginator(page, limit);
    const offset = paging.getOffset();

    try {
      let where = { status: [STATUS.ACTIVE] };
      if (search) {
        Object.assign(where, {
          full_name: { [Op.iLike]: `%${search}%` },
        });
        // Object.assign(where, {
        //   [Op.or]: [
        //     {
        //       full_name: {
        //         [Op.iLike]: `%${search}%`,
        //       },
        //     }, = 10
        //     {
        //       email: {
        //         [Op.iLike]: `%${search}%`,
        //       },
        //     },
        //   ],
        // });
      }

      queryResult = await Company.findAndCountAll({
        attributes: [
          'id',
          'name',
          'address',
          'code',
          'telp',
          'handphone',
          'email',
          'status',
        ],
        where,
        limit,
        offset,
      });

      let template = {
        count: queryResult.count,
        rows: queryResult.rows.map((company) => ({
          id: company.id,
          name: company.name,
          address: company.address,
          code: company.code,
          telp: company.telp,
          handphone: company.handphone,
          email: company.email,
          status: company.status,
        })),
      };

      paging.setData(template);
      const resp = paging.getPaginator();
      return outputParser.success(req, res, 'List Partner Success', resp);
    } catch (err) {
      Log.error(err);
      return outputParser.error(req, res, 'Internal Server Error');
    }
  }

  static async createNewPartner(req, res) {
    try {
      const errors = validationResult(req);

      if (!errors.isEmpty()) {
        Log.error(errors);
        return outputParser.errorValidatorFirst(req, res, errors);
      }

      const { name, address, telp, handphone, email } = req.body;

      // let categoryName = category_name.replace(/(\b\w)/g, (match) => match.toUpperCase());

      // const existingUser = await Company.findOne({ where: { category_name } });
      // if (existingUser) {
      //   return outputParser.errorCustom(req, res, 'Email sudah terdaftar');
      // }
      // generateCompanyCode();

      await Company.create({
        name,
        address,
        code: generateCompanyCode(name),
        telp,
        handphone,
        email,
        status: 'ACTIVE',
      });

      return outputParser.success(req, res, 'Create Partner Success');
    } catch (err) {
      return outputParser.errorCustom(req, res, err.message, null);
    }
  }
}

module.exports = {
  CompanyController,
};
