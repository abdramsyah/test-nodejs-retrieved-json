const { CompanyController } = require('./company.js');
const PartnerValidator = require('./validator.js');

module.exports = {
  CompanyController,
  PartnerValidator,
};
