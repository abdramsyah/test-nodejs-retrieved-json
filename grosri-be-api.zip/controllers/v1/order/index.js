const { OrderController } = require('./order');

module.exports = {
  OrderController,
};
